package br.com.fatec;

public class Main {
}
